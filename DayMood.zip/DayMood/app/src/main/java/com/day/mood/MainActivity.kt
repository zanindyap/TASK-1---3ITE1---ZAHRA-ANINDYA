package com.day.mood

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.day.mood.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var bind:ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bind = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bind.root)
        initEvent();
    }
    private fun initEvent(){
        bind.btnHappy.setOnClickListener{
            btnOutput("happy")
        }
        bind.btnSad.setOnClickListener{
            btnOutput("sad")
        }
        bind.btnMad.setOnClickListener{
            btnOutput("mad")
        }
    }

    private fun validateInput():Boolean{
        if(bind.etName.text.toString().isEmpty()){
            Toast.makeText(this,"Please input your name",Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    private fun btnOutput(mood:String){
        if(validateInput()){
            Toast.makeText(this,"Hi ${bind.etName.text}, You are $mood today.",Toast.LENGTH_SHORT).show()
        }
    }
}